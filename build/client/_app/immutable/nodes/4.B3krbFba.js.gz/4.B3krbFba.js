import{t as e,a as t}from"../chunks/DCgk2Fd3.js";import"../chunks/BGibhl7j.js";import{c as o,r as s}from"../chunks/qL8Nd1dR.js";import{B as r}from"../chunks/CJeyJvmh.js";var d=e('<div class="bg-gray-800"><!></div>');function v(i){var a=d(),n=o(a);r(n,{title:"Chappell Roan-Inspired Audio Visualizer",href:"https://katiehellmann.github.io/audio-visualizer/",note:"View it here!",src:"../audioviz.png",headline:"Don't you like this audio visualizer? I made it so you'll dance with me-",tags:`Languages and Frameworks: HTML, CSS, JavaScript, Canvas API
Version Control: GitHub
Platforms: Web
`,content:`
The Assignment: 
Create and customize an Audio Visualizer using JavaScript, HTML, CSS, and the Canvas API. 

Contributions: 
 - Improved my working knowledge of JavaScript, JavaScript Objects, ES5/ES6 functions, Canvas API
 - Hosted using GitHub Pages
`}),s(a),t(i,a)}export{v as component};
