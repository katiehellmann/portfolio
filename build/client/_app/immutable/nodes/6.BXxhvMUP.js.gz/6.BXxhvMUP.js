import{t as o,a}from"../chunks/DCgk2Fd3.js";import"../chunks/BGibhl7j.js";import{c as r,r as i}from"../chunks/qL8Nd1dR.js";import{B as s}from"../chunks/CJeyJvmh.js";var d=o('<div class="bg-gray-800"><!></div>');function p(t){var e=d(),n=r(e);s(n,{title:"Scare Parts",href:"https://devpost.com/software/scare-parts",note:"Our DevPost!",src:"../scareparts.jpg",headline:`An action shooting game where me and my friends fused into a haunted ghost-powered van by an evil spirit but it’s okay! Because we’re connected through friendship and Twitch chat.
`,tags:`Engine: Unity
Languages: C#
Version Control: GitHub
Platforms: Windows
Team Size: 9
Development Period: 26 hours
`,content:`
Game Overview: 
Four adventure-seeking college kids and their dog friend embark on the beginning of their paranormal journey when they find the Hand Hook Car Man, who takes all of their souls and combines them into their ghost hunting truck. Now they have to work together and dodge and collect spirits and cryptids to hunt down the Hand Hook Car Man and return to their human bodies.

Contributions: 
 - Used a websocket to integrate Twitch internet relay chats (IRCs) to create unique Unity Events based on Twitch Chat Commands.
 - Expanded my personal knowledge of networking protocols
 - Worked with a team consisting of 8 other peers
`}),i(e),a(t,e)}export{p as component};
